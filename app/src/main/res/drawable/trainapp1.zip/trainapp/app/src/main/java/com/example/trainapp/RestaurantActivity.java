package com.example.trainapp;

import android.os.Bundle;
import android.view.View;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.LinearLayout;
import android.widget.Spinner;
import android.widget.TextView;
import android.widget.Toast;
import androidx.appcompat.app.AppCompatActivity;
import androidx.cardview.widget.CardView;
import android.util.Log;


public class RestaurantActivity extends AppCompatActivity {

    private Button btnMarkPreparing, btnMarkReady, btnAssignDelivery, btnConfirmAssignment;
    private LinearLayout assignDeliveryLayout;
    private Spinner deliveryPersonSpinner;
    private CardView orderCard;
    private TextView orderDetailsText, orderStatusText, restaurantNameText;

    private DatabaseHelper dbHelper;
    private String currentOrderId;
    private String currentRestaurantName;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_restaurant);

        dbHelper = new DatabaseHelper(this);

        // Get restaurant name from intent
        currentRestaurantName = getIntent().getStringExtra("RESTAURANT_NAME");
        Log.d("RestaurantActivity", "Started with name: " + currentRestaurantName);

        if (currentRestaurantName == null || currentRestaurantName.trim().isEmpty()) {
            Toast.makeText(this, "Restaurant name not found!", Toast.LENGTH_SHORT).show();
            finish();
            return;
        }

        initializeViews();
        restaurantNameText.setText(currentRestaurantName);

        loadActiveOrderForRestaurant(currentRestaurantName);
        setupDeliveryPersonsSpinner();
        setupButtonListeners();
    }

    private void initializeViews() {
        btnMarkPreparing = findViewById(R.id.btnMarkPreparing);
        btnMarkReady = findViewById(R.id.btnMarkReady);
        btnAssignDelivery = findViewById(R.id.btnAssignDelivery);
        btnConfirmAssignment = findViewById(R.id.btnConfirmAssignment);
        assignDeliveryLayout = findViewById(R.id.assignDeliveryLayout);
        deliveryPersonSpinner = findViewById(R.id.deliveryPersonSpinner);

        orderCard = findViewById(R.id.orderCard);
        orderDetailsText = findViewById(R.id.orderDetailsText);
        orderStatusText = findViewById(R.id.orderStatusText);
        restaurantNameText = findViewById(R.id.restaurantName);  // Make sure this ID exists in your XML
    }

    private void loadActiveOrderForRestaurant(String restaurantName) {
        Order order = dbHelper.getActiveOrderByRestaurantName(restaurantName);

        if (order != null) {
            currentOrderId = order.getOrderId();
            orderDetailsText.setText(order.getDetails());
            orderStatusText.setText("Status: " + order.getStatus());
            updateButtonStates(order.getStatus());
        } else {
            Toast.makeText(this, "No active orders for " + restaurantName, Toast.LENGTH_SHORT).show();
            orderDetailsText.setText("No active orders");
            orderStatusText.setText("");
            disableAllButtons();
        }
    }

    private void updateButtonStates(String status) {
        switch (status) {
            case "Received":
                setButtonStates(true, false, false);
                break;
            case "Preparing":
                setButtonStates(false, true, false);
                break;
            case "Ready":
                setButtonStates(false, false, true);
                break;
            case "Assigned":
                disableAllButtons();
                btnAssignDelivery.setText("Assigned to Delivery");
                break;
            default:
                disableAllButtons();
                break;
        }
    }

    private void setButtonStates(boolean preparing, boolean ready, boolean assign) {
        btnMarkPreparing.setEnabled(preparing);
        btnMarkReady.setEnabled(ready);
        btnAssignDelivery.setEnabled(assign);
    }

    private void disableAllButtons() {
        setButtonStates(false, false, false);
    }

    private void setupDeliveryPersonsSpinner() {
        String[] deliveryPersons = dbHelper.getAvailableDeliveryPersons();
        if (deliveryPersons == null || deliveryPersons.length == 0) {
            deliveryPersons = new String[]{"No delivery persons available"};
            btnAssignDelivery.setEnabled(false);
        }

        ArrayAdapter<String> adapter = new ArrayAdapter<>(this,
                android.R.layout.simple_spinner_item, deliveryPersons);
        adapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
        deliveryPersonSpinner.setAdapter(adapter);
    }

    private void setupButtonListeners() {
        btnMarkPreparing.setOnClickListener(v -> {
            if (updateOrderStatus("Preparing")) {
                orderStatusText.setText("Status: Preparing");
                updateButtonStates("Preparing");
                Toast.makeText(this, "Order marked as Preparing", Toast.LENGTH_SHORT).show();
            }
        });

        btnMarkReady.setOnClickListener(v -> {
            if (updateOrderStatus("Ready")) {
                orderStatusText.setText("Status: Ready");
                updateButtonStates("Ready");
                Toast.makeText(this, "Order marked as Ready", Toast.LENGTH_SHORT).show();
            }
        });

        btnAssignDelivery.setOnClickListener(v -> assignDeliveryLayout.setVisibility(View.VISIBLE));

        btnConfirmAssignment.setOnClickListener(v -> assignOrderToDeliveryPerson());
    }

    private boolean updateOrderStatus(String status) {
        boolean success = dbHelper.updateOrderStatus(currentOrderId, status);
        if (!success) {
            Toast.makeText(this, "Failed to update status", Toast.LENGTH_SHORT).show();
        }
        return success;
    }

    private void assignOrderToDeliveryPerson() {
        String selectedPerson = deliveryPersonSpinner.getSelectedItem().toString();

        if ("No delivery persons available".equals(selectedPerson)) {
            Toast.makeText(this, "No delivery persons available", Toast.LENGTH_SHORT).show();
            return;
        }

        boolean assigned = dbHelper.assignOrderToDelivery(currentOrderId, selectedPerson);

        if (assigned) {
            Toast.makeText(this, "Order assigned to " + selectedPerson, Toast.LENGTH_SHORT).show();
            assignDeliveryLayout.setVisibility(View.GONE);
            btnAssignDelivery.setText("Assigned to Delivery");
            btnAssignDelivery.setEnabled(false);
            orderStatusText.setText("Status: Assigned");
            updateButtonStates("Assigned");
        } else {
            Toast.makeText(this, "Assignment failed", Toast.LENGTH_SHORT).show();
        }
    }
}
