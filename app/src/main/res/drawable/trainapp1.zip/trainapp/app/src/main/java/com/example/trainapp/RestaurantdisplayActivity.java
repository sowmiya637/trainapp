package com.example.trainapp;

import android.content.Intent;
import android.database.Cursor;
import android.os.Bundle;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Button;
import android.widget.Toast;
import androidx.appcompat.app.AppCompatActivity;
import android.util.Log;

public class RestaurantdisplayActivity extends AppCompatActivity {

    private ImageView restaurantImage;
    private TextView restaurantName, restaurantContact, restaurantLocation, restaurantCategory;
    private Button viewOrderButton;
    private DatabaseHelper dbHelper;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_restaurantdisplay);

        initializeViews();  // Initialize UI elements
        dbHelper = new DatabaseHelper(this);

        // Get restaurant name from intent
        String nameFromIntent = getIntent().getStringExtra("RESTAURANT_NAME");
        if (nameFromIntent != null && !nameFromIntent.isEmpty()) {
            showSpecificRestaurant(nameFromIntent);
        } else {
            Toast.makeText(this, "No restaurant name passed", Toast.LENGTH_SHORT).show();
        }

        // Navigate to RestaurantActivity on button click
        viewOrderButton.setOnClickListener(v -> {
            String name = restaurantName.getText().toString().trim();

            if (name.isEmpty()) {
                Toast.makeText(RestaurantdisplayActivity.this, "Restaurant name is missing!", Toast.LENGTH_SHORT).show();
                return;
            }

            Log.d("RestaurantDisplay", "Starting RestaurantActivity with name: " + name);

            Intent intent = new Intent(RestaurantdisplayActivity.this, RestaurantActivity.class);
            intent.putExtra("RESTAURANT_NAME", name);

            startActivity(intent);

            Log.d("RestaurantDisplay", "Intent started");
        });
    }  // <-- Closing brace for onCreate

    // Initialize views outside onCreate
    private void initializeViews() {
        restaurantImage = findViewById(R.id.restaurantImage);
        restaurantName = findViewById(R.id.restaurantName);
        restaurantContact = findViewById(R.id.restaurantContact);
        restaurantLocation = findViewById(R.id.restaurantLocation);
        restaurantCategory = findViewById(R.id.restaurantCategory);
        viewOrderButton = findViewById(R.id.viewOrderButton);
    }

    // Show restaurant details by querying database
    private void showSpecificRestaurant(String name) {
        Cursor cursor = dbHelper.getRestaurantByName(name);
        if (cursor != null && cursor.moveToFirst()) {

            int nameIndex = cursor.getColumnIndex(DatabaseHelper.COLUMN_NAME);
            int contactIndex = cursor.getColumnIndex(DatabaseHelper.COLUMN_CONTACT);
            int addressIndex = cursor.getColumnIndex(DatabaseHelper.COLUMN_ADDRESS);
            int cityIndex = cursor.getColumnIndex(DatabaseHelper.COLUMN_CITY);
            int categoryIndex = cursor.getColumnIndex(DatabaseHelper.COLUMN_CATEGORY);

            if (nameIndex >= 0) {
                restaurantName.setText(cursor.getString(nameIndex));
            }

            if (contactIndex >= 0) {
                restaurantContact.setText(cursor.getString(contactIndex));
            }

            if (addressIndex >= 0 && cityIndex >= 0) {
                String fullAddress = cursor.getString(addressIndex) + ", " + cursor.getString(cityIndex);
                restaurantLocation.setText(fullAddress);
            } else {
                restaurantLocation.setText("Location not available");
            }

            if (categoryIndex >= 0) {
                restaurantCategory.setText(cursor.getString(categoryIndex));
            } else {
                restaurantCategory.setText("Category not available");
            }

            cursor.close();
        } else {
            Toast.makeText(this, "Restaurant not found", Toast.LENGTH_SHORT).show();
        }
    }

    @Override
    protected void onDestroy() {
        dbHelper.close();
        super.onDestroy();
    }
}
